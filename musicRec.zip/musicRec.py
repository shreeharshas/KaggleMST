# START FILE HANDLING CODE#
# start read from songs file song lists
f = open('kaggle_songs.txt', 'r')
ksongs = list()
ksongs = f.read().splitlines()
f.close()
# start read from songs file song lists

# start read from users file
f = open('kaggle_users.txt', 'r')
kusers = list()
kusers = f.read().splitlines()
f.close()
# start read from users file

# start read from relation file
#f = open("kaggle_visible_evaluation_triplets.txt", "r")
f = open("kaggle_visible_evaluation_triplets_min.txt", "r")
ktrain = list()
ktrain = f.read().splitlines()
f.close()
# end read from relation file

# START POPULATING DATASTRUCTURES
# start get all users list
users = list()
usertable = dict()
for c_user in range(0, len(kusers)):
    splitlist = kusers[c_user].split('\t')
    users.append(splitlist[0].split('\n')[0])
    usertable[splitlist[0]] = list(splitlist)
# end get all users list

#print usertable

# start get all songs list
songs = list()
songtable = dict()
for c_song in range(0, len(ksongs)):
    splitlist = ksongs[c_song].split('\t')
    songs.append(splitlist[0].split('\n')[0])
    songtable[splitlist[0]] = list(splitlist)
# end get all songs list


# start get all relations list
# 0 - user 1 - song 2 - playcount
train = list()
train_user = dict()
train_song = dict()
train_playcount = dict()

for c_relation in range(0, len(ktrain)):
    splitlist = ktrain[c_relation].split('\t')
    train.append(splitlist)
    #print splitlist
    tempList = list()
    if splitlist[0] in train_user:
        train_user[splitlist[0]].append(splitlist[1])
        train_user[splitlist[0]].append(splitlist[2])
    else:
        tempList.append(splitlist[1])
        tempList.append(splitlist[2])
        train_user[splitlist[0]] = tempList

    tempList = list()
    if splitlist[1] in train_song:
        train_song[splitlist[1]].append(splitlist[0])
        train_song[splitlist[1]].append(splitlist[2])
    else:
        tempList.append(splitlist[0])
        tempList.append(splitlist[2])
        train_song[splitlist[1]] = tempList

    tempList = list()
    if splitlist[2] in train_playcount:
        train_playcount[splitlist[2]].append(splitlist[0])
        train_playcount[splitlist[2]].append(splitlist[1])
    else:
        tempList.append(splitlist[0])
        tempList.append(splitlist[1])
        train_playcount[splitlist[2]] = tempList

# end get all relations list

# start Find average playcount for every song
sumCounts = dict()
for relation in train:
    sumCountPair = list()
    # 0 - sum    1 - count
    num = int(relation[2])

    if relation[1] in sumCounts:
        sumCountPair = sumCounts[relation[1]]
        sumCountPair[0] += num
        sumCountPair[1] += 1
        sumCounts[relation[1]] = sumCountPair
    else:
        sumCountPair.append(num)
        sumCountPair.append(1)
        sumCounts[relation[1]] = sumCountPair


averageCounts = dict()
for x in sumCounts.iteritems():
    sng = x[0]
    averageCounts[sng] = float(x[1][0])/x[1][1]
# end Find average playcount for every song

# start calculate minimum playcount for whole song set
minPlayCount = 0
avgSum = 0
for x in averageCounts.iteritems():
    avgSum += x[1]

minPlayCount = avgSum/len(averageCounts)  # found this to be 2.89991071906
# end calculate minimum playcount for whole song set


#start find similar users
similarUsersBySong = dict()

for x in averageCounts.iteritems():
    if x[1]>=minPlayCount:
        for y in train:
            if x[0] == y[1]:
                if x[0] in similarUsersBySong:
                    similarUsersBySong[x[0]].append(y[0])
                else:
                    tempList = list()
                    tempList.append(y[0])
                    similarUsersBySong[x[0]] = tempList
#end find similar users

#start removing redundant users
similarUsersBySongGroup = dict()
for z in similarUsersBySong.iteritems():
    if len(z[1]) > 1:
        similarUsersBySongGroup[z[0]] = z[1]
#end removing redundant users

#start song suggestions
suggestedSongsByUser = dict()
for u in similarUsersBySongGroup.iteritems():
    for v in train_user.iteritems():
        if v[0] in u[1]:
            tempList = list()
            tempList.append(v[1][0::2])
            suggestedSongsByUser[v[0]] = tempList

for w in suggestedSongsByUser.iteritems():
    print w
# end song suggestions